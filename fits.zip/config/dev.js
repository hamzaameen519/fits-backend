module.exports = {
  APP_URL: "http://localhost:5000",
  DEBUG_MODE: true,
  DB_URL:
    "mongodb+srv://admin:admin@cluster0.9pglw.mongodb.net/fitsDB?retryWrites=true&w=majority",
  JWT_SECRET: "FITSTEAMJWTSECRET",
  REFRESH_SECRET: "FITSTEAMREFRESHTOKEN",
  API_KEY:
    "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",
};

// module.exports = {
//   APP_URL,
//   APP_PORT,
//   DEBUG_MODE,
//   DB_URL,
//   JWT_SECRET,
//   REFRESH_SECRET,
// } = process.env;
